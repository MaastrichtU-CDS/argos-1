Please move the files in this folder to the principal folder of your local CTP installation on the RECEIVER SIDE e.g. the side that is hosting XNAT.

The command block from Lines 9 to 15 assumes you will be receiving data via HTTP/HTTPS.

The command block from Lines 17 to 32 assumes whatever you receive by HTTP/HTTPS you shall DICOM-forward directly into XNAT.

Line 24 is telling the RECEIVER CTP where to find the XNAT instance that it is going to DICOM-forward into; XNATR defaults to port 8104 to listen for Dicom data.

*** IMPORTANT PART BELOW ***
The default port to listen for HTTP/HTTPS incoming data is 23104.

IF YOU CHANGE THIS PORT AND/OR YOUR IP ADDRESS, you must inform the SENDER to change accordingly in the SENDER's CTP or else the data will not be able to come to you.

You need to confirm with IT Services on both sides if on the sending end, you can send outgoing data to this destination, then on the receiving end, whether they will allow incoming data on this port.
****************************


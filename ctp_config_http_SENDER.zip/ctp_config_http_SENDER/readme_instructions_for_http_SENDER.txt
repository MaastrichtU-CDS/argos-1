Please move the files in this folder to the principal folder of your local CTP installation on the SENDER SIDE e.g. the clinic side.

You need to edit the following lines with the pathway to your folder where you want CTP to pick up dicom jobs to process :
Line 7
Line 12

The command block from Lines 53 to 63 assumes you will be pushing images to XNAT via HTTP or HTTPS.

*** IMPORTANT PART BELOW ***
You need to edit Line 57 to be the IP address and port number of your HTTP/HTTPS receiver, by default the port is 23104.

You need to confirm with IT Services on both sides if on the sending end, you can send outgoing data to this destination, then on the receiving end, whether they will allow incoming data on this port.
****************************

The command block from Lines 82 to 92 will save a copy of whatever is being pushed xnat into a local folder.
You can set this local backup folder at Line 89.
If you do not want this, leave the command block commented, otherwise - if you do want to make a backup - uncomment it.

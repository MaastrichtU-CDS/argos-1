Add these files to the "script" subfolder of your local CTP installation.

1. Use Notepad++ to edit. In the script called "ARGOS Pipeline - MAASTRO" you would edit the following lines :
- Line 5 : change "ARGOSnode01" to the literal Project ID that you are using as your XNAT collection
- Lines 2 to 11 can be OPTIONALLY edited if you wish but not absolutely necessary

2. Use Notepad++ to edit. In the script called "DicomAnonymizerXnat" you would edit the following lines :
- Line 2 : change "ARGOSnode01" to the Project ID that you are using in your XNAT

3. Use Notepad++ to edit. In the file called "ARGOS_deidentification_lookup" you would add research IDs for your ARGOS subjects. Please do not use any hospital ID, medical record number or social security number. This is where you assign the conversion from your own internal ID numbers to a proper research study number.

NB : The file you edited in Step 3 above is very important to keep secure and private inside your institution. This file should never be exposed outside of your own clinic.

4. In the subfolder called DECIDE scripts, there are some additional helper scripts to help you automatically rename the labels of regions of interest. The scripts here reduce all your ROI names to lowercase, then replaces blank spaces with "_".

5. In the subfolder called DECIDE scripts, the only file you need to edit is called "roi-lookup-table". The examples provided here shows that ALL labels called either "gtvp" or "gtv-1" (after lowercase and whitespace replacement) will get automatically renamed to "GTV-1". You can edit this to rename the structure set labels in your dataset to something else.

NB : This is a batch process that will affect all patients labels at the same time.

